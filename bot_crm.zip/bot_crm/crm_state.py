from aiogram.dispatcher.filters.state import StatesGroup, State


class CRM_state(StatesGroup):
    object1 = State()
    object2 = State()
    bank1_1 = State()
    bank1_2 = State()
    bank1_3 = State()
    phone = State()
    phone_adder = State()
    client_dell = State()
    remind = State()
    debt = State()
    obj = State()