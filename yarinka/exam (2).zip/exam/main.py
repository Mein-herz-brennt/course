from wsgiref.simple_server import make_server
import cgi
import json
import random

HOST = ""
port = 7000


def json_writer(info: list):
    filename = "file" + str(random.randint(10**2, 10**5)) + ".json"
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(info, file, ensure_ascii=False)
    return filename


def get_parni(string: str):
    lst_str = string.split(" ")
    parni = []
    for i in range(len(lst_str)):
        if i % 2 == 0:
            parni.append(lst_str[i])
    return json_writer(parni)


def app(env, start_response):
    with open("index.html", "r", encoding="utf-8") as file:
        text = file.read()

    form = cgi.FieldStorage(fp=env["wsgi.input"], environ=env)

    words = form.getfirst("words", "")
    if words:
        filename = get_parni(words)
        with open(filename, "r", encoding="utf-8") as file:
            html_content = file.read()

        start_response("200 OK", [("Content-Type:", "text/json;  cherset=utf-8")])
        return [bytes(html_content, encoding="utf-8")]
    else:
        start_response("200 OK", [("Content-type:", "text/html;  cherset=utf-8")])
        return [bytes(text, encoding="utf-8")]


if __name__ == '__main__':
    print(f'Starting server in http://localhost:{port}')
    httpd = make_server(HOST, port, app)
    httpd.serve_forever()
