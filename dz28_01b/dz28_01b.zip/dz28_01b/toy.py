import xml.etree.ElementTree as Et


class Toy:
    def __init__(self, filename: str):  # filename it's name our xml file in format "file.xml"
        self.et = Et.ElementTree(file=filename)
        self.root = self.et.getroot()

    def get_all_info_about(self):
        all_info = []
        # info_about_toy = {"name":"",
        #                   "years":"",
        #                   "price":""}
        for child in self.root:
            name = child.find("title").text
            years = child.find("years").text
            price = child.find("price").text
            info_about_toy = {"name": name,
                              "years": years,
                              "price": price}
            all_info.append(info_about_toy)
        return all_info

    def find_toy_by_name(self, name: str):
        all_info = self.get_all_info_about()
        toys_list = []
        try:
            for i in all_info:
                if i["name"] == name:
                    toys_list.append(
                        f"""<p>Назва іграшки: {i['name']}, ціна: {i['price']}грн, вікові обмеження: {i['years']}</p>""")
            return toys_list
        except Exception as e:
            print(f"Exception --> {e}")
            return "Sorry but we don't have this toy"

    def find_by_min_and_max_price(self, min_price, max_price):
        all_info = self.get_all_info_about()
        toys_list = []
        try:
            for i in all_info:
                if int(min_price) <= int(i["price"]) <= int(max_price):
                    toys_list.append(
                        f"""<p>Назва іграшки: {i['name']}, ціна: {i['price']}грн, вікові обмеження: {i['years']}</p>""")
            return toys_list
        except Exception as e:
            print(f"Exception --> {e}")
            return "Sorry but we don't have toys in this price"

    def find_toys_by_years(self, years=0):
        year = int(years)
        all_info = self.get_all_info_about()
        toys_list = []
        # try:
        for i in all_info:
            alder = i["years"].split("-")
            if alder[1] != "+":
                if int(alder[0]) <= year <= int(alder[1]):
                    toys_list.append(
                        f"""<p>Назва іграшки: {i['name']}, ціна: {i['price']}грн, вікові обмеження: {i['years']}</p>""")
            else:
                if int(alder[0]) <= year:
                    toys_list.append(
                        f"""<p>Назва іграшки: {i['name']}, ціна: {i['price']}грн, вікові обмеження: {i['years']}</p>""")
        return toys_list
        # except Exception as e:
        #     print(f"Exception --> {e}")
        #     return "Sorry but we don't have toys for this age"

    def get_all_toys_names(self):
        all_info = self.get_all_info_about()
        names = [i["name"] for i in all_info]
        return names


if __name__ == '__main__':
    a = Toy("toys.xml")
    print(a.find_toys_by_years("85"))
    print(a.find_toy_by_name("Лялька Barbie"))
    print(a.find_by_min_and_max_price("85", "700"))
