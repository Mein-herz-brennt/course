import cgi


def dot(vector1: list, vector2: list):
    if len(vector1) != len(vector2):
        return "Ви вказали вектори різної розмірності"
    try:
        for i in range(len(vector1)):
            vector1[i] = float(vector1[i])
        for i in range(len(vector2)):
            vector2[i] = float(vector2[i])
        dot = sum(p * q for p, q in zip(vector1, vector2))
        return str(dot)
    except Exception:
        return "Елементи вектора повинні бути числами записаними через пробіл"


if __name__ == '__main__':
    form = cgi.FieldStorage()
    vector1 = form.getfirst("first", "")
    vector2 = form.getfirst("second", "")
    result = dot(str(vector1).split(" "), str(vector2).split(" "))
    with open("out_index.html", encoding="utf-8") as file:
        html_content = file.read()
    html_content = html_content.replace("res1", vector1)
    html_content = html_content.replace("res2", vector2)
    html_content = html_content.replace("res3", result)
    print("Content-Type: text/html; charset=utf-8\n")
    print(html_content)
